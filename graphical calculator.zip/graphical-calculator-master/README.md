# graphical-calculator
This is simple calculator using c and c++. In this i have graphics function of c and c++ like text, line, color etc. Subscribe Channel CodeSky => https://bit.ly/codesky
